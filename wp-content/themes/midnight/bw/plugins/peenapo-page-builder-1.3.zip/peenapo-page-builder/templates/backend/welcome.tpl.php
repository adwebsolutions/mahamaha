<div id="bwpb-welcome">
    <h2><?php _e( 'Hi there! Welcome to Peenapo Page Builder', PBTD ); ?></h2>
    <p><?php _e('Peenapo Pege Builder is a back end, drag and drop, shortcode based plugin that allows you<br>to quickly and easily build pages with our themes. Start by clicking the button "Add new element".',PBTD ); ?></p>
    <!--p><?php _e('For more tips, please visit the <a href="http://page.builder.peenapo.com/documentation/" target="_blank">online documentation</a>.',PBTD ); ?></p-->
</div>